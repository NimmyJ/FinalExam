    <div class="container">
		<div class="margin-top">

			
				<div class="span2">
				<h4></h4>
			
				</div>
				<div class="span10">
				
				
				
					
					<div class="text_content">
					<div class="abc">
					<!-- text content -->
					<h4>MVC: Definition</h4>
					<hr>
					<p style="text-align: justify;">
					What is MVC:
					Model–view–controller (MVC) is a software architectural pattern for implementing user interfaces on computers. It divides a given application into three interconnected parts.
					</p>
					<hr>
					<h4>History</h4>
					<hr>
					<p style="text-align: justify;">
					History:
					One of the seminal insights in the early development of graphical user interfaces, MVC became one of the first approaches to describe and implement software constructs in terms of their responsibilities.
					</p>
					<hr>
					</div>
					</div>
					<!-- end content -->
				
				
				</div>
			
			</div>
		</div>
    </div>
