
<?php include('../Controller/Controller.php')

?>	


<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	$cont = new Controller();
	$cont->Invoke();
}



?>



<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-image: url('../View/bg.png');>


		<div class="margin-top">
			<div class="row">	
			<div class="span12">
			</div>

 <div class="alert alert-info"><p><b>Login Member<b></p></div>
	<div>Please Enter Details Below</div>		

						<form method="POST" style="margin-left: 500px; width:400px;margin-top: 50px">
								<div>
									<label class="control-label" for="inputEmail">Username</label>
									<div class="controls">
									<input type="text" name="firstname" id="firstname" placeholder="First Name" required style="width: 400px">
									</div>
								</div>
										<div>
										<label class="control-label" for="inputPassword">Cellphone Number:</label>
										<div class="controls">
										<input type='tel' pattern="[0-9]{11,11}" class="search" name="contact"  placeholder="Phone Number"  autocomplete="off"  maxlength="11" style="width: 400px" >
										</div>
								</div>
								<div>
									<div>
									<button id="login" name="submit" type="submit" style="margin-top: 30px;margin-left:170px"><i class="icon-signin icon-large" ></i>&nbsp;Submit</button>
								</div>
								</div>
								



						
						</form>

	</div>
</div>


</body>
</html>


