<?php

require_once("../Model/model.php");

class model{
	public function getlogin(){


             include('dbcon.php');
						



						if (isset($_REQUEST['firstname']) &&isset($_REQUEST['contact'])) {
					
								$firstname = $_POST['firstname'];
								$contact = $_POST['contact'];


							$query = "SELECT * FROM member WHERE firstname='$firstname' AND contact='$contact'";
								$result = mysql_query($query)or die(mysql_error());
								$num_row = mysql_num_rows($result);
									$row=mysql_fetch_array($result);
									if( $num_row > 0 ) {


								echo "<script type='text/javascript'>alert('Success');
								window.location.href='../View/Home.php';
								</script>";
									}
									else{


									echo "<script type='text/javascript'>alert('failed');
									</script>";
									} ?>
								<div class="alert alert-danger">Access Denied</div>		
								<?php
								}}


		}
	
