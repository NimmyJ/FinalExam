<?php 

require_once('../Model/model.php');

class Controller{



public function __construct()
{
	$this->model = new Model();
}



public function invoke()
{
	$result = $this->model->getlogin();


	if ($result == 'login') {
		include 'View/Home.php';
	}
	else{
	}
}

}